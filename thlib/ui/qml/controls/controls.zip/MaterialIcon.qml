import QtQuick

// Shared semantic icon renderer backed by the official Font Awesome 5
// Regular/Solid fonts bundled with TACTIC-Handler's qtawesome package.
Item {
    id: root
    property string name: ""
    required property color color
    property real size: 24
    property real opticalScale: 0.78
    property bool forceSolid: false
    readonly property string iconSet:
        typeof appController !== "undefined"
        ? String(appController.icon_set || "automatic")
        : "automatic"
    readonly property var solidGlyphs:
        typeof fontAwesomeSolidGlyphs !== "undefined"
        ? fontAwesomeSolidGlyphs : ({})
    readonly property var regularGlyphs:
        typeof fontAwesomeRegularGlyphs !== "undefined"
        ? fontAwesomeRegularGlyphs : ({})
    readonly property string solidFontFamily:
        typeof fontAwesomeSolidFontFamily !== "undefined"
        ? fontAwesomeSolidFontFamily : "Segoe UI"
    readonly property string regularFontFamily:
        typeof fontAwesomeRegularFontFamily !== "undefined"
        ? fontAwesomeRegularFontFamily : solidFontFamily
    readonly property var materialGlyphs:
        typeof materialDesignIconGlyphs !== "undefined"
        ? materialDesignIconGlyphs : ({})
    readonly property string materialFontFamily:
        typeof materialDesignIconFontFamily !== "undefined"
        ? materialDesignIconFontFamily : solidFontFamily
    implicitWidth: size
    implicitHeight: size

    readonly property var aliases: ({
        "account-circle": "user-circle",
        "account-tree": "project-diagram",
        "activity-feed": "stream",
        "advanced-search": "search-plus",
        "admin-panel-settings": "user-shield",
        "all": "layer-group",
        "add": "plus",
        "add-circle": "plus-circle",
        "add-comment": "comments",
        "add-task": "plus-circle",
        "add-alarm": "clock",
        "add-photo-alternate": "file-image",
        "api": "exchange-alt",
        "api-client": "exchange-alt",
        "arrow-forward": "arrow-right",
        "arrow-downward": "arrow-down",
        "arrow-upward": "arrow-up",
        "attach-file": "paperclip",
        "attachment": "paperclip",
        "attachments-editor": "paperclip",
        "available": "check-circle",
        "bug-report": "bug",
        "cancel": "times-circle",
        "cancelled": "times-circle",
        "category": "shapes",
        "cached": "sync-alt",
        "check-circle": "check-circle",
        "checkbox-blank-circle": "circle",
        "checkbox-multiple-marked-outline": "check-double",
        "check": "check",
        "chevron-left": "chevron-left",
        "chevron-right": "chevron-right",
        "close": "times",
        "code": "code",
        "cloud-done": "cloud",
        "cloud-download": "cloud-download-alt",
        "cloud-off": "unlink",
        "cloud-sync": "cloud-sync",
        "checkin": "cloud-upload-alt",
        "checkin-options": "sliders-h",
        "checkout": "cloud-download-alt",
        "child": "level-down-alt",
        "commit-queue": "cloud-upload-alt",
        "complete": "check-circle",
        "completed": "check-circle",
        "configuration": "cog",
        "collections": "images",
        "continious": "stream",
        "content-copy": "copy",
        "content-cut": "cut",
        "content-paste": "paste",
        "content-save": "save",
        "control-point-duplicate": "clone",
        "create-new-folder": "folder-plus",
        "dashboard-customize": "th-large",
        "dashboard": "th-large",
        "delete": "trash-alt",
        "delete-forever": "trash-alt",
        "delete-sweep": "broom",
        "deployed-code": "cube",
        "description": "file-alt",
        "dns": "server",
        "done-all": "check-double",
        "drag-handle": "bars",
        "drop-plate": "inbox",
        "duplicate": "clone",
        "dynamic-feed": "stream",
        "emoji": "smile",
        "drive-file-rename-outline": "edit",
        "edit-note": "sticky-note",
        "error": "exclamation-circle",
        "expand-less": "chevron-up",
        "expand-more": "chevron-down",
        "failed": "exclamation-circle",
        "file": "file",
        "filter-alt": "filter",
        "filter-alt-off": "eraser",
        "format-paragraph": "paragraph",
        "format-header-1": "heading",
        "format-header-2": "text-height",
        "format-header-3": "font",
        "calendar-month": "calendar-alt",
        "calendar-today": "calendar-day",
        "floating": "window-restore",
        "donut-small": "circle-notch",
        "folder-open": "folder-open",
        "folder-special": "folder",
        "forum": "comments",
        "gantt": "stream",
        "help": "question-circle",
        "history": "history",
        "groups": "users",
        "grid-view": "th",
        "group": "users",
        "group-add": "user-plus",
        "hierarchy": "sitemap",
        "hourglass-empty": "hourglass",
        "hub": "network-wired",
        "icon": "image",
        "import": "file-import",
        "input": "sign-in-alt",
        "open-in-new": "external-link-alt",
        "open-in-full": "expand",
        "insert-drive-file": "file",
        "inventory-2": "archive",
        "keyboard-arrow-down": "chevron-down",
        "keyboard-arrow-right": "chevron-right",
        "language": "globe",
        "layers": "layer-group",
        "link-off": "unlink",
        "loading": "spinner",
        "logout": "sign-out-alt",
        "menu": "bars",
        "matching-templates": "object-group",
        "milestone": "flag",
        "maya": "cube",
        "maya-import": "file-import",
        "maya-open": "folder-open",
        "maya-reference": "link",
        "image-edit": "image",
        "message": "comments",
        "messages": "comments",
        "more-horiz": "ellipsis-h",
        "more-vert": "ellipsis-v",
        "movie": "film",
        "monitoring": "chart-line",
        "more-time": "clock",
        "move-to-inbox": "inbox",
        "network-check": "network-wired",
        "naming-editor": "edit",
        "notes": "sticky-note",
        "notifications": "bell",
        "online": "plug",
        "open": "external-link-alt",
        "pages": "file-alt",
        "person": "user",
        "person-add": "user-plus",
        "unassigned": "user-slash",
        "payments": "money-bill-wave",
        "picture-in-picture": "clone",
        "photo-camera": "camera",
        "ui-performance": "tachometer-alt",
        "play-arrow": "play",
        "play-selection": "play-circle",
        "playlist-add": "list-ul",
        "plus-box": "plus-square",
        "preview-editor": "image",
        "priority-high": "exclamation",
        "process": "cogs",
        "process-marker": "circle",
        "progress": "sync-alt",
        "publication": "cloud-upload-alt",
        "approval": "check-circle",
        "bar-chart": "chart-bar",
        "publish": "cloud-upload-alt",
        "push-pin": "thumbtack",
        "refresh": "redo-alt",
        "radio-button-unchecked": "circle",
        "restart-alt": "redo-alt",
        "rename": "edit",
        "repo-sync": "cloud-sync",
        "repository-editor": "folder-open",
        "repository-sync": "cloud-sync",
        "reply": "reply",
        "running": "sync-alt",
        "save": "save",
        "schedule": "clock",
        "sidebar-link": "link",
        "sidebar-section": "folder",
        "sidebar-separator": "grip-lines",
        "select-all": "check-double",
        "science": "flask",
        "schema": "project-diagram",
        "screenshot-maker": "camera",
        "script-expression": "function",
        "script-javascript": "language-javascript",
        "script-python": "language-python",
        "script-xml": "xml",
        "scripts-tree": "chevron-left",
        "send": "paper-plane",
        "sequence": "film",
        "server-presets": "server",
        "sensors": "broadcast-tower",
        "settings": "cog",
        "settings-suggest": "tools",
        "snapshot": "camera",
        "sobject": "cube",
        "stopped": "stop-circle",
        "storage": "hdd",
        "status": "dot-circle",
        "sort-items": "sort-alpha-down",
        "sort-ascending": "sort-alpha-down",
        "sort-descending": "sort-alpha-up",
        "group-items": "object-group",
        "ungroup-items": "object-ungroup",
        "subdirectory-arrow-right": "level-down-alt",
        "success": "check-circle",
        "sync": "sync-alt",
        "sync-problem": "exclamation-triangle",
        "swap-vert": "exchange-alt",
        "swap-horiz": "exchange-alt",
        "system-activity": "heartbeat",
        "system-update": "download",
        "theme-mode": "adjust",
        "tab": "window-maximize",
        "table-view": "table",
        "task": "tasks",
        "task-alt": "check-circle",
        "tasks": "tasks",
        "tiles": "th",
        "tune": "sliders-h",
        "type": "font",
        "undo": "undo-alt",
        "unavailable": "ban",
        "update": "redo-alt",
        "redo": "redo-alt",
        "upload": "upload",
        "verified": "check-circle",
        "view-agenda": "list-alt",
        "view-column": "columns",
        "view-in-ar": "cube",
        "view-kanban": "columns",
        "view-list": "list",
        "view-sequential": "stream",
        "warning": "exclamation-triangle",
        "workspaces": "briefcase",
        "window-restore": "window-restore",
        "visibility": "eye",
        "visibility-off": "eye-slash",
        "workflow": "project-diagram",
        "wrap-lines": "wrap",
        "zoom-in": "search-plus",
        "zoom-out": "search-minus"
    })

    readonly property var materialAliases: ({
        "activity-feed": "chart-timeline-variant",
        "advanced-search": "magnify-plus",
        "admin-panel-settings": "shield-account",
        "all": "layers",
        "api": "swap-horizontal",
        "api-client": "swap-horizontal",
        "swap-horiz": "swap-horizontal",
        "arrow-forward": "arrow-right",
        "attach-file": "paperclip",
        "attachments-editor": "paperclip",
        "bug-report": "bug",
        "cached": "sync",
        "cancel": "close-circle",
        "category": "shape",
        "checkin": "cloud-upload",
        "checkin-options": "tune",
        "checkout": "cloud-download",
        "child": "subdirectory-arrow-right",
        "collections": "image-multiple",
        "configuration": "cog",
        "content-copy": "content-copy",
        "content-cut": "content-cut",
        "content-paste": "content-paste",
        "control-point-duplicate": "content-duplicate",
        "create-new-folder": "folder-plus",
        "dashboard-customize": "view-dashboard-edit",
        "delete-forever": "delete-forever",
        "delete-sweep": "delete-sweep",
        "deployed-code": "cube",
        "description": "text-box",
        "done-all": "check-all",
        "drag-handle": "drag",
        "drive-file-rename-outline": "rename-box",
        "edit-note": "note-edit",
        "failed": "alert-circle",
        "filter-alt": "filter",
        "filter-alt-off": "filter-off",
        "floating": "open-in-new",
        "folder-special": "folder-star",
        "forum": "forum",
        "gantt": "chart-gantt",
        "grid-view": "view-grid",
        "group-add": "account-multiple-plus",
        "security": "shield-account",
        "groups": "account-group",
        "hierarchy": "file-tree",
        "hourglass-empty": "timer-sand",
        "inventory-2": "archive",
        "keyboard-arrow-down": "chevron-down",
        "keyboard-arrow-right": "chevron-right",
        "matching-templates": "shape-outline",
        "messages": "message-text",
        "more-horiz": "dots-horizontal",
        "more-vert": "dots-vertical",
        "network-check": "lan-connect",
        "notes": "note-text",
        "online": "lan-connect",
        "open-in-full": "arrow-expand-all",
        "open-in-new": "open-in-new",
        "pages": "file-document-multiple",
        "person": "account",
        "person-add": "account-plus",
        "photo-camera": "camera",
        "picture-in-picture": "picture-in-picture-bottom-right",
        "play-arrow": "play",
        "playlist-add": "playlist-plus",
        "preview-editor": "image-edit",
        "priority-high": "alert",
        "process": "cogs",
        "publication": "cloud-upload",
        "radio-button-unchecked": "radiobox-blank",
        "repo-sync": "cloud-sync",
        "repository-editor": "folder-cog",
        "repository-sync": "cloud-sync",
        "restart-alt": "restart",
        "screenshot-maker": "camera",
        "settings-suggest": "cog-refresh",
        "sidebar-link": "link",
        "sidebar-section": "folder",
        "sidebar-separator": "drag-horizontal",
        "sobject": "cube",
        "sort-items": "sort-alphabetical-ascending",
        "sort-ascending": "sort-alphabetical-ascending",
        "sort-descending": "sort-alphabetical-descending",
        "status": "circle-double",
        "storage": "harddisk",
        "subdirectory-arrow-right": "subdirectory-arrow-right",
        "task-alt": "checkbox-marked-circle",
        "theme-mode": "theme-light-dark",
        "view-agenda": "view-agenda",
        "view-column": "view-column",
        "view-in-ar": "cube-scan",
        "view-kanban": "view-column",
        "view-list": "view-list",
        "warning": "alert",
        "window-restore": "window-restore",
        "workspaces": "briefcase",
        "wrap-lines": "wrap"
    })

    readonly property var automaticOutlineGlyphs: ({
        "address-book": true,
        "bell": true,
        "bookmark": true,
        "calendar": true,
        "clock": true,
        "comments": true,
        "copy": true,
        "edit": true,
        "file": true,
        "file-alt": true,
        "file-image": true,
        "folder": true,
        "folder-open": true,
        "image": true,
        "paper-plane": true,
        "sticky-note": true,
        "user": true,
        "user-circle": true,
        "window-maximize": true
    })

    function normalizedName(sourceName) {
        return String(sourceName || "warning").replace(/_/g, "-")
    }

    function fontAwesomeName(sourceName) {
        const normalized = normalizedName(sourceName)
        const candidate = aliases[normalized] || normalized
        return solidGlyphs[candidate] !== undefined
                || regularGlyphs[candidate] !== undefined
            ? candidate : ""
    }

    function materialName(sourceName) {
        const normalized = normalizedName(sourceName)
        const direct = materialAliases[normalized] || normalized
        if (materialGlyphs[direct] !== undefined)
            return direct
        const fontAwesome = aliases[normalized] || normalized
        const mapped = materialAliases[fontAwesome] || fontAwesome
        return materialGlyphs[mapped] !== undefined ? mapped : ""
    }

    function glyphName(sourceName) {
        return fontAwesomeName(sourceName) || "exclamation-triangle"
    }

    Text {
        objectName: "materialIconGlyph"
        readonly property string fontAwesomeName:
            root.fontAwesomeName(root.name)
        readonly property string resolvedName:
            fontAwesomeName || "exclamation-triangle"
        readonly property string materialName:
            root.materialName(root.name)
        readonly property bool solidAvailable:
            root.solidGlyphs[resolvedName] !== undefined
        readonly property bool regularAvailable:
            root.regularGlyphs[resolvedName] !== undefined
        readonly property bool useMaterial:
            !root.forceSolid && materialName.length > 0
            && (root.iconSet === "material-design"
                || fontAwesomeName.length === 0)
        readonly property bool useRegular:
            !root.forceSolid && !useMaterial && regularAvailable
            && (root.iconSet === "fontawesome-outline"
                || (root.iconSet === "automatic"
                    && root.automaticOutlineGlyphs[resolvedName] === true)
                || !solidAvailable)
        anchors.fill: parent
        text: useMaterial
            ? root.materialGlyphs[materialName]
            : useRegular
            ? root.regularGlyphs[resolvedName]
            : root.solidGlyphs[resolvedName] || ""
        color: root.color
        font.family: useMaterial
            ? root.materialFontFamily
            : useRegular
            ? root.regularFontFamily : root.solidFontFamily
        font.pixelSize: Math.max(11, Math.round(root.size * root.opticalScale))
        font.weight: useMaterial || useRegular
            ? Font.Normal : Font.Black
        font.hintingPreference: Font.PreferVerticalHinting
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        renderType: Text.QtRendering
        antialiasing: true
    }
}
