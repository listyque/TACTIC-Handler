import QtQuick
import QtQuick.Controls
import QtQuick.Controls as QtControls
import QtQuick.Window
import QtQuick.Shapes
import Qt5Compat.GraphicalEffects
import "." as Controls

// Shared owner for every transient menu, selector and anchored panel.
// Placement is resolved before open(). A native Popup.Window must never be
// moved again from QML after it has been shown: doing so races Qt's own popup
// placement and produces the visible left/right jump seen on Windows.
QtControls.Popup {
    id: control

    required property var theme
    property bool animationsEnabled: theme.popupAnimationsEnabled
    property real surfaceRadius: theme.menuRadius
    property bool usePopupWindow: true
    property bool coordinateGlobally: true
    property bool coordinateOpenPopups: coordinateGlobally
    property bool protectNextOpenFromDuplicateInput: false
    property int openingInputGuardDuration:
        theme.baseMotionExtended + theme.baseMotionFast
    property int settledClosePolicy: QtControls.Popup.CloseOnEscape
        | QtControls.Popup.CloseOnPressOutside
    property real shadowMargin: 12
    property real screenMargin: 4
    property real availableScreenWidth: 0
    property real availableScreenHeight: 0
    property bool sourceWasOpen: false
    property int sameSourceToggleWindow: 180
    property bool restoreOwnerActivationOnClose: true
    property var openingAnchorItem: null
    property bool anchorPointerVisible: false
    property real anchorPointerSize: 12
    property real anchorPointerWidth: anchorPointerSize * 1.35
    property real anchorPointerHeight: anchorPointerSize * 0.55
    property real anchorPointerCenter: width / 2
    property string anchorPointerEdge: "top"
    property color surfaceColor: theme.surfaceContainerHigh
    property color surfaceBorderColor: theme.outlineVariant
    property real surfaceBorderWidth: 1

    readonly property real maximumAvailableWidth:
        availableScreenWidth > 0
            ? Math.max(1, availableScreenWidth - 2 * screenMargin)
            : 1000000
    readonly property real maximumAvailableHeight:
        availableScreenHeight > 0
            ? Math.max(1, availableScreenHeight - 2 * screenMargin)
            : 1000000
    readonly property real effectiveShadowMargin:
        usePopupWindow ? shadowMargin : 0
    readonly property bool openingInputGuardActive:
        _openingInputGuardActive
    readonly property real anchorPointerInset:
        anchorPointerVisible ? Math.ceil(anchorPointerHeight) : 0

    property int _placementGeneration: 0
    property int _pendingGeneration: 0
    property bool _reopenPending: false
    property bool _openingInputGuardActive: false
    property bool _placementPrepared: false
    property real _preparedX: 0
    property real _preparedY: 0
    property real _requestedSurfaceGlobalX: 0
    property real _requestedSurfaceGlobalY: 0
    property real _anchorGlobalCenterX: Number.NaN
    property var _popupWindow: null
    property bool _nativeModalityApplied: false
    property bool _suppressOwnerActivationOnce: false

    padding: 6
    leftPadding: padding + effectiveShadowMargin
    rightPadding: padding + effectiveShadowMargin
    topPadding: padding + effectiveShadowMargin
        + (anchorPointerVisible && anchorPointerEdge === "top"
            ? anchorPointerInset : 0)
    bottomPadding: padding + effectiveShadowMargin
        + (anchorPointerVisible && anchorPointerEdge === "bottom"
            ? anchorPointerInset : 0)
    popupType: usePopupWindow
        ? QtControls.Popup.Window : QtControls.Popup.Item
    closePolicy: _openingInputGuardActive
        ? QtControls.Popup.CloseOnEscape : settledClosePolicy

    // Own the transitions explicitly: inherited Qt style durations do not
    // follow application preferences and cannot be safely toggled via null.
    enter: Transition {
        enabled: control.animationsEnabled
        NumberAnimation {
            property: "scale"; from: 0.9; to: 1
            duration: control.animationsEnabled ? control.theme.popupMotionSlow : 0
            easing.type: Easing.OutQuint
        }
        NumberAnimation {
            property: "opacity"; from: 0; to: 1
            duration: control.animationsEnabled ? control.theme.popupMotionFast : 0
            easing.type: Easing.OutCubic
        }
    }
    exit: Transition {
        enabled: control.animationsEnabled
        NumberAnimation {
            property: "scale"; from: 1; to: 0.9
            duration: control.animationsEnabled ? control.theme.popupMotionSlow : 0
            easing.type: Easing.OutQuint
        }
        NumberAnimation {
            property: "opacity"; from: 1; to: 0
            duration: control.animationsEnabled ? control.theme.popupMotionFast : 0
            easing.type: Easing.OutCubic
        }
    }
    Overlay.modal: Controls.PopupScrim { theme: control.theme }
    Overlay.modeless: Controls.PopupScrim { theme: control.theme }

    onAboutToShow: {
        _openingInputGuardActive = protectNextOpenFromDuplicateInput
        protectNextOpenFromDuplicateInput = false
        if (_openingInputGuardActive)
            openingInputGuard.restart()
        else
            openingInputGuard.stop()

        if (_placementPrepared)
            resolvePreparedPosition()
        if (coordinateOpenPopups)
            Controls.PopupCoordinator.activate(control)
    }

    onOpened: {
        // Popup.Window creates its transient QQuickPopupWindow during open().
        // Modality is the only native-window property owned here after show.
        if (!usePopupWindow || !contentItem)
            return
        const popupWindow = contentItem.Window.window
        if (!popupWindow)
            return
        _popupWindow = popupWindow
        _nativeModalityApplied = modal
        if (modal)
            popupWindow.modality = Qt.WindowModal
    }

    onClosed: {
        openingInputGuard.stop()
        _openingInputGuardActive = false
        protectNextOpenFromDuplicateInput = false
        const ownerWindow = _popupWindow
            ? _popupWindow.transientParent : null
        if (_popupWindow && _nativeModalityApplied)
            _popupWindow.modality = Qt.NonModal
        _popupWindow = null
        _nativeModalityApplied = false
        // Restore the owner only while it is still the active application
        // window. Never reactivate it after the user switched applications.
        if (restoreOwnerActivationOnClose
                && !_suppressOwnerActivationOnce
                && ownerWindow && ownerWindow.active)
            ownerWindow.requestActivate()
        _suppressOwnerActivationOnce = false
        if (coordinateOpenPopups)
            Controls.PopupCoordinator.release(control)
        finishPendingReopen()
    }

    function protectOpeningFrom(sourceItem) {
        if (!sourceItem)
            return
        try {
            const activationAt = Number(sourceItem.lastActivationAt)
            const recentActivation = Number.isFinite(activationAt)
                && Date.now() - activationAt <= openingInputGuardDuration
            if (sourceItem.lastActivationWasTouch === true
                    && (recentActivation || !Number.isFinite(activationAt)))
                protectNextOpenFromDuplicateInput = true
        } catch (error) {
            // Plain QML and native Qt controls do not expose activation type.
        }
    }

    function rememberSourceOpen() {
        sourceWasOpen = opened || visible
    }

    function wasJustClosedFrom(sourceItem) {
        return openingAnchorItem === sourceItem
            && Controls.PopupCoordinator.wasJustClosed(
                control, sameSourceToggleWindow
            )
    }

    function suppressOwnerActivationOnce() {
        _suppressOwnerActivationOnce = true
    }

    function availableGeometryAt(globalX, globalY) {
        if (typeof pointerController !== "undefined") {
            try {
                const area = pointerController.available_geometry_at(
                    Number(globalX), Number(globalY))
                if (area && Number(area.width) > 0
                        && Number(area.height) > 0) {
                    return {
                        "x": Number(area.x),
                        "y": Number(area.y),
                        "width": Number(area.width),
                        "height": Number(area.height)
                    }
                }
            } catch (error) {
                // Isolated QML tests do not expose the application service.
            }
        }
        const ownerWindow = parent ? parent.Window.window : null
        const screen = ownerWindow ? ownerWindow.screen : null
        const area = screen ? screen.availableGeometry : null
        if (!area || Number(area.width) <= 0 || Number(area.height) <= 0)
            return null
        return {
            "x": Number(area.x),
            "y": Number(area.y),
            "width": Number(area.width),
            "height": Number(area.height)
        }
    }

    function clampedCoordinate(value, minimum, maximum) {
        return maximum < minimum
            ? minimum : Math.max(minimum, Math.min(maximum, value))
    }

    function prepareGlobalPosition(surfaceGlobalX, surfaceGlobalY) {
        if (!parent)
            return false

        _requestedSurfaceGlobalX = Number(surfaceGlobalX)
        _requestedSurfaceGlobalY = Number(surfaceGlobalY)
        _placementPrepared = true
        return resolvePreparedPosition()
    }

    function resolvePreparedPosition() {
        if (!parent || !_placementPrepared)
            return false

        const surfaceGlobalX = _requestedSurfaceGlobalX
        const surfaceGlobalY = _requestedSurfaceGlobalY

        const area = availableGeometryAt(surfaceGlobalX, surfaceGlobalY)
        if (area) {
            availableScreenWidth = area.width
            availableScreenHeight = area.height
        }

        let outerGlobalX = Number(surfaceGlobalX) - effectiveShadowMargin
        let outerGlobalY = Number(surfaceGlobalY) - effectiveShadowMargin
        if (area) {
            const popupWidth = Math.max(1, Number(width || implicitWidth || 1))
            const popupHeight = Math.max(
                1, Number(height || implicitHeight || 1))
            outerGlobalX = clampedCoordinate(
                outerGlobalX,
                area.x + screenMargin,
                area.x + area.width - popupWidth - screenMargin)
            outerGlobalY = clampedCoordinate(
                outerGlobalY,
                area.y + screenMargin,
                area.y + area.height - popupHeight - screenMargin)
        }

        if (anchorPointerVisible
                && Number.isFinite(_anchorGlobalCenterX)) {
            anchorPointerCenter = clampedCoordinate(
                _anchorGlobalCenterX - outerGlobalX,
                effectiveShadowMargin + surfaceRadius,
                Math.max(
                    effectiveShadowMargin + surfaceRadius,
                    width - effectiveShadowMargin - surfaceRadius
                )
            )
        }

        const localPoint = parent.mapFromGlobal(outerGlobalX, outerGlobalY)
        _preparedX = Math.round(localPoint.x)
        _preparedY = Math.round(localPoint.y)
        x = _preparedX
        y = _preparedY
        return true
    }

    function preparePositionAtItem(sourceItem, localX, localY) {
        if (!sourceItem || !parent)
            return false
        openingAnchorItem = sourceItem
        const point = sourceItem.mapToGlobal(localX, localY)
        return prepareGlobalPosition(point.x, point.y)
    }

    function requestOpenPrepared() {
        const generation = ++_placementGeneration
        _pendingGeneration = generation
        if (opened || visible) {
            _reopenPending = true
            close()
            return
        }
        _reopenPending = false
        resolvePreparedPosition()
        open()
    }

    function reopenAtPosition(targetX, targetY, globalX, globalY) {
        openingAnchorItem = null
        let resolvedGlobalX = Number(globalX)
        let resolvedGlobalY = Number(globalY)
        if (!Number.isFinite(resolvedGlobalX)
                || !Number.isFinite(resolvedGlobalY)) {
            if (!parent)
                return
            const point = parent.mapToGlobal(targetX, targetY)
            resolvedGlobalX = point.x
            resolvedGlobalY = point.y
        }
        prepareGlobalPosition(resolvedGlobalX, resolvedGlobalY)
        requestOpenPrepared()
    }

    function reopenAtItem(sourceItem, localX, localY, preferCursorPosition) {
        if (!sourceItem || !parent)
            return
        openingAnchorItem = sourceItem
        let point = sourceItem.mapToGlobal(localX, localY)
        if (preferCursorPosition
                && typeof pointerController !== "undefined") {
            try {
                const cursorPoint = pointerController.global_position()
                if (cursorPoint)
                    point = cursorPoint
            } catch (error) {
                // Isolated QML tests do not expose the pointer service.
            }
        }
        prepareGlobalPosition(point.x, point.y)
        requestOpenPrepared()
    }

    function openBelowItem(
            sourceItem, alignRight, gap, rightOverhang) {
        if (!sourceItem || !parent) {
            open()
            return
        }
        openingAnchorItem = sourceItem
        protectOpeningFrom(sourceItem)
        const resolvedGap = Number(gap || 0)
        const surfaceWidth = Math.max(
            1, width - 2 * effectiveShadowMargin)
        const surfaceHeight = Math.max(
            1, height - 2 * effectiveShadowMargin)
        const resolvedRightOverhang = Number(rightOverhang || 0)
        const localX = alignRight
            ? sourceItem.width - surfaceWidth + resolvedRightOverhang : 0
        const below = sourceItem.mapToGlobal(
            localX, sourceItem.height + resolvedGap)
        const sourceTop = sourceItem.mapToGlobal(localX, 0)
        const sourceCenter = sourceItem.mapToGlobal(
            sourceItem.width / 2, 0)
        const area = availableGeometryAt(below.x, below.y)
        let targetY = below.y
        if (area && below.y + surfaceHeight > area.y + area.height
                && sourceTop.y - resolvedGap - surfaceHeight >= area.y)
            targetY = sourceTop.y - resolvedGap - surfaceHeight
        _anchorGlobalCenterX = sourceCenter.x
        anchorPointerEdge = targetY === below.y ? "top" : "bottom"
        prepareGlobalPosition(below.x, targetY)
        requestOpenPrepared()
    }

    function openCenteredIn(ownerItem) {
        if (!ownerItem || !parent) {
            open()
            return
        }
        openingAnchorItem = null
        const surfaceWidth = Math.max(
            1, width - 2 * effectiveShadowMargin)
        const surfaceHeight = Math.max(
            1, height - 2 * effectiveShadowMargin)
        const point = ownerItem.mapToGlobal(
            (ownerItem.width - surfaceWidth) / 2,
            (ownerItem.height - surfaceHeight) / 2)
        prepareGlobalPosition(point.x, point.y)
        requestOpenPrepared()
    }

    function toggleBelowItem(sourceItem, alignRight, gap) {
        protectOpeningFrom(sourceItem)
        if (openingInputGuardActive) {
            sourceWasOpen = false
            return
        }
        if (sourceWasOpen || opened || visible
                || wasJustClosedFrom(sourceItem)) {
            cancelPendingReopen()
            if (opened || visible)
                close()
        } else {
            openBelowItem(sourceItem, alignRight, gap)
        }
        sourceWasOpen = false
    }

    function cancelPendingReopen() {
        _reopenPending = false
        ++_placementGeneration
        if (coordinateOpenPopups && !opened && !visible)
            Controls.PopupCoordinator.release(control)
    }

    function finishPendingReopen() {
        if (!_reopenPending)
            return
        const generation = _pendingGeneration
        _reopenPending = false
        Qt.callLater(function() {
            if (generation === _placementGeneration)
                control.open()
        })
    }

    Timer {
        id: openingInputGuard
        interval: control.openingInputGuardDuration
        onTriggered: control._openingInputGuardActive = false
    }

    background: Item {
        Item {
            id: surfaceSource
            anchors.fill: parent

            Shape {
                id: anchorPointer
                objectName: "popupAnchorPointer"
                visible: control.anchorPointerVisible
                width: control.anchorPointerWidth
                height: control.anchorPointerHeight
                x: control.anchorPointerCenter - width / 2
                y: control.anchorPointerEdge === "top"
                    ? control.effectiveShadowMargin
                    : control.height - control.effectiveShadowMargin - height
                antialiasing: true
                ShapePath {
                    fillColor: control.surfaceColor
                    strokeColor: "transparent"
                    strokeWidth: 0
                    startX: 0
                    startY: control.anchorPointerEdge === "top"
                        ? anchorPointer.height : 0
                    PathLine {
                        x: anchorPointer.width / 2
                        y: control.anchorPointerEdge === "top"
                            ? 0 : anchorPointer.height
                    }
                    PathLine {
                        x: anchorPointer.width
                        y: control.anchorPointerEdge === "top"
                            ? anchorPointer.height : 0
                    }
                    PathLine {
                        x: 0
                        y: control.anchorPointerEdge === "top"
                            ? anchorPointer.height : 0
                    }
                }
                ShapePath {
                    fillColor: "transparent"
                    strokeColor: control.surfaceBorderColor
                    strokeWidth: control.surfaceBorderWidth
                    capStyle: ShapePath.RoundCap
                    joinStyle: ShapePath.RoundJoin
                    startX: 0
                    startY: control.anchorPointerEdge === "top"
                        ? anchorPointer.height : 0
                    PathLine {
                        x: anchorPointer.width / 2
                        y: control.anchorPointerEdge === "top"
                            ? 0 : anchorPointer.height
                    }
                    PathLine {
                        x: anchorPointer.width
                        y: control.anchorPointerEdge === "top"
                            ? anchorPointer.height : 0
                    }
                }
            }
            Rectangle {
                id: surface
                objectName: "popupSurface"
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.bottom: parent.bottom
                anchors.leftMargin: control.effectiveShadowMargin
                anchors.rightMargin: control.effectiveShadowMargin
                anchors.topMargin: control.effectiveShadowMargin
                    + (control.anchorPointerVisible
                        && control.anchorPointerEdge === "top"
                        ? control.anchorPointerInset : 0)
                anchors.bottomMargin: control.effectiveShadowMargin
                    + (control.anchorPointerVisible
                        && control.anchorPointerEdge === "bottom"
                        ? control.anchorPointerInset : 0)
                radius: control.surfaceRadius
                color: control.surfaceColor
                border.width: control.surfaceBorderWidth
                border.color: control.surfaceBorderColor
            }
            Rectangle {
                visible: control.anchorPointerVisible
                width: Math.max(
                    0,
                    control.anchorPointerWidth
                        - 2 * control.surfaceBorderWidth
                )
                height: control.surfaceBorderWidth + 1
                x: control.anchorPointerCenter - width / 2
                y: control.anchorPointerEdge === "top"
                    ? control.effectiveShadowMargin
                        + control.anchorPointerInset
                        - control.surfaceBorderWidth / 2
                    : control.height - control.effectiveShadowMargin
                        - control.anchorPointerInset
                        - control.surfaceBorderWidth / 2
                color: control.surfaceColor
            }
        }
        Loader {
            anchors.fill: parent
            active: control.visible
            sourceComponent: DropShadow {
                anchors.fill: parent
                source: surfaceSource
                horizontalOffset: 0
                verticalOffset: 4
                radius: 10
                samples: 21
                color: control.theme.popupShadow
                transparentBorder: true
            }
        }
    }
}
